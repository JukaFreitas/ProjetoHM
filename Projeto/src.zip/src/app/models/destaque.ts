export type Destaque = {
    destaqueImagem : string; 
}