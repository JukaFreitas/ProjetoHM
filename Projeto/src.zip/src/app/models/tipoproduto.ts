export type Tipoproduto = {
    id?: number, 
   tipo: "string", 
}
