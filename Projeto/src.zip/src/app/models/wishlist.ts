export type Wishlist = {
    id?: number, 
    userId: number, 
    produtoId: number
}
