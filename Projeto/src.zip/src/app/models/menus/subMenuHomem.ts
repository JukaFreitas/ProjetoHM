export const subMenuHomem: string[] = [
    "Casacos",
    "Camisas",
     "Calças",
    "Sweatshirts",
    "Polos",
    "Sapatos",
    " Todos"
]