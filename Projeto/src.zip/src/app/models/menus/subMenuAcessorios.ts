export const subMenuAcessorios: string[] = [
    "Malas",
    "Pulseiras",
    "Anéis"
]