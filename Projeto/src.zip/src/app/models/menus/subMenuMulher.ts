export const subMenuMulher: string[] = [
    "Vestidos",
    "Blusões",
    "Coletes",
    "Jeans",
    "Saias",
    "Calções",
    "Lingerie",
    "Sapatos",
    "Malas",
    "Todos"
]