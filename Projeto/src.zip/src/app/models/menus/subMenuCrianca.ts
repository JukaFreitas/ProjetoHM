export const subMenuCrianca: string[] = [
    "Menina | 6-14 Anos",
    " Menino | 6-14 Anos",
    "Bebé Menina | 3 Meses - 5 Anos",
    "Bebé Menino | 3 Meses - 5 Anos",
    "Mini | 0-12 Meses"
]