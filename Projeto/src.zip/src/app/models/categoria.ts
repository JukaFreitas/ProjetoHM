export const categoria : string[] = [
    "Criança", 
    "Homem", 
    "Mulher"
]