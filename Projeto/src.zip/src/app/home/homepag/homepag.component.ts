import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homepag',
  templateUrl: './homepag.component.html',
  styleUrls: ['./homepag.component.css']
})
export class HomepagComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
